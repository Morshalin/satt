/* ------------------------------------------------------------------------------
 *
 *  # Login pages
 *
 *  Demo JS code for a set of login and registration pages
 *
 *  CopyRight © TeamTRT
 *
 * ---------------------------------------------------------------------------- */


// Setup module
// ------------------------------

var LoginRegistration = function() {

  //
  // Return objects assigned to module
  //
  var _componentValidation = function() {
    $('#registration_form').parsley().on('field:validated', function() {
      $('.parsley-ajax').remove();
        var ok = $('.parsley-error').length === 0;
        $('.bs-callout-info').toggleClass('hidden', !ok);
        $('.bs-callout-warning').toggleClass('hidden', ok);
    });
    $('#registration_form').on('submit', function(e) {
        e.preventDefault();
        $('.parsley-ajax').remove();
        $('#submit').attr('disabled',true);
        $('#submit').text('Creating Account');
        var submit_url = $('#registration_form').attr('action');
        //Start Ajax
        var formData = new FormData($("#registration_form")[0]);
         formData.append('registration', 'registration');
        $.ajax({
            url: submit_url,
            type: 'POST',
            data: formData,
            contentType: false, // The content type used when sending data to the server.
            cache: false, // To unable request pages to be cached
            processData: false,
            dataType: 'JSON',
            success: function(data) {
                if (!data.success) {
                  var i = 0;
                  $.each(data.errors, function(key, value) {
                    if($('#' + key).length > 0){
                      $('#' + key).parsley().addError('ajax', {
                          message: value,
                          updateClass: true
                      });
                    }
                    new PNotify({
                        title: 'Error',
                        text: value,
                        type: 'error',
                        addclass: 'alert alert-styled-left',
                    });

                  });
                } else{
                  swal({
                   title: 'Good job!',
                   text: data.message,
                   type: 'success'
               });
                  if (data.goto) {
                    $('#registration_form')[0].reset();
                    setTimeout(function(){
                      window.location.href = data.goto;
                    }, 2000);
                  }
                }
                $('#submit').attr('disabled',false);
                $('#submit').text('Create Account');
            },
            error: function(data) {
              $('#submit').attr('disabled',false);
              $('#submit').text('Create Account');
            }
        });
    });
  };

  var _componentUniform = function() {
      if (!$().uniform) {
          console.warn('Warning - uniform.min.js is not loaded.');
          return;
      }

      // Initialize
      $('.form-input-styled').uniform();
  };

  var _componentSelect2 = function() {
      if (!$().select2) {
          console.warn('Warning - select2.min.js is not loaded.');
          return;
      }

      // Initialize
      $('.select').select2();
  };

  return {
      initComponents: function() {
          _componentValidation();
          _componentUniform();
          _componentSelect2();
      }
  }
}();


// Initialize module
// ------------------------------

document.addEventListener('DOMContentLoaded', function() {
  LoginRegistration.initComponents();
});

$(document).ready(function(){

$(document).on('change', '#email', function() {
    var submit_url = $('#registration_form').attr('action');
    var email = $(this).val();
    //Start Ajax
    $.ajax({
        url: submit_url,
        type: 'POST',
        data: {email: email, checkmail: 'checkmail'},
        dataType: 'JSON',
        success: function(data) {
            if (!data.success) {
                if($('#email').length > 0){
                  $('#email').parsley().addError('ajax', {
                      message: data.message,
                      updateClass: true
                  });
                  new PNotify({
                      title: 'Error',
                      text: data.message,
                      type: 'error',
                      addclass: 'alert alert-styled-left',
                  });
                }
            } else{
              $('#email').parsley().removeError('ajax', {
                  updateClass: true
              });
            }
            $('#submit').show();
            $('#submiting').hide();

        },
        error: function(data) {

            $('#submit').show();
            $('#submiting').hide();
        }
    });
});

$(document).on('change', '#user_name', function() {
    var submit_url = $('#registration_form').attr('action');
    var user_name = $(this).val();
    //Start Ajax
    $.ajax({
        url: submit_url,
        type: 'POST',
        data: {user_name: user_name, checkuser: 'checkuser'},
        dataType: 'JSON',
        success: function(data) {
            if (!data.success) {
                if($('#user_name').length > 0){
                  $('#user_name').parsley().addError('ajax', {
                      message: data.message,
                      updateClass: true
                  });
                  new PNotify({
                      title: 'Error',
                      text: data.message,
                      type: 'error',
                      addclass: 'alert alert-styled-left',
                  });
                }
            } else{
              $('#user_name').parsley().removeError('ajax', {
                  updateClass: true
              });
            }

        },
        error: function(data) {

        }
    });
});

});
