/* ------------------------------------------------------------------------------
 *
 *  # Login pages
 *
 *  Demo JS code for a set of login and registration pages
 *
 *  CopyRight © TeamTRT
 *
 * ---------------------------------------------------------------------------- */


// Setup module
// ------------------------------

var LoginRegistration = function() {

    //
    // Return objects assigned to module
    //
    var _componentValidation = function() {
      $('#login_form').parsley().on('field:validated', function() {
        $('.parsley-ajax').remove();
          var ok = $('.parsley-error').length === 0;
          $('.bs-callout-info').toggleClass('hidden', !ok);
          $('.bs-callout-warning').toggleClass('hidden', ok);
      });
      $('#login_form').on('submit', function(e) {
          e.preventDefault();
          $('#submit').attr('disabled',true);
          $('#submit').text('Submiting');
          var submit_url = $('#login_form').attr('action');
          //Start Ajax
          var formData = new FormData($("#login_form")[0]);
           formData.append('login', 'login');
          $.ajax({
              url: submit_url,
              type: 'POST',
              data: formData,
              contentType: false, // The content type used when sending data to the server.
              cache: false, // To unable request pages to be cached
              processData: false,
              dataType: 'JSON',
              success: function(data) {
                  if (!data.success) {
                    var i = 0;
                    $.each(data.errors, function(key, value) {
                      if($('#' + key).length > 0){
                        $('#' + key).parsley().addError('ajax', {
                            message: value,
                            updateClass: true
                        });
                      }
                      new PNotify({
                          title: 'Error',
                          text: value,
                          type: 'error',
                          addclass: 'alert alert-styled-left',
                      });

                    });
                    var html = `<div class="alert alert-`+data.status+` alert-styled-left alert-bordered">
                          <button type="button" class="close" data-dismiss="alert"><span>&times;</span><span class="sr-only">Close</span></button>
                          <span class="text-semibold">Please Check Your Login Form Carefully.</span>
                    </div>`;
                    $('#alert_message').html(html);
                  } else{
                    var html = `<div class="alert alert-`+data.status+` alert-styled-left alert-bordered">
                          <button type="button" class="close" data-dismiss="alert"><span>&times;</span><span class="sr-only">Close</span></button>
                          <span class="text-semibold">`+data.message+`</span>
                    </div>`;
                    $('#alert_message').html(html);
                    swal({
                     title: 'Good job!',
                     text: data.message,
                     type: 'success'
                 });
                    if (data.goto) {
                      $('#login_form')[0].reset();
                      setTimeout(function(){
                        window.location.href = data.goto;
                      }, 2000);
                    }
                  }
                  $('#submit').attr('disabled',false);
                  $('#submit').text('Submit');
              },
              error: function(data) {
                $('#submit').attr('disabled',false);
                $('#submit').text('Submit');
              }
          });
      });
    };

    return {
        initComponents: function() {
            _componentValidation();
        }
    }
}();


// Initialize module
// ------------------------------

document.addEventListener('DOMContentLoaded', function() {
    LoginRegistration.initComponents();
});
